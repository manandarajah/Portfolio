#pragma once
#include <array>
#include <string>
#include <iostream>

using namespace std;

class Card {
private:
	char num, suit;

public:
	static const array<char, 13> numbers;
	static const array<char, 4> suits;
	//Compares a card by number of suit. Returns true if number or suit matches, returns false if no match
	Card();
	static Card currentCard;
	bool compare(Card* card);
	//Get card information
	char getNum();
	char getSuit();
	//Displays the card on the pile
	static void displayCardInField(Card* card);
};

class Player {
private:
	array<Card*, 8> hand;
	bool isTurn;
	char suitCall;

public:
	//Uses random function to generate card and returns the card
	Player();
	Card* getCard(int index);
	void drawCard();
	void setIsTurn(bool isTurn);
	bool getIsTurn();
	void setSuitCall(char suitCall);
	char getSuitCall();
	void clearSuitCall();
	int cardCount();
	void showHand();
	void removeCard(int index);
};