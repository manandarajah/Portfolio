#include "pch.h"
#include "Classes.h"
#include <stdlib.h>

const array<char, 13> Card::numbers{ 'A', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'J', 'Q', 'K' };
const array<char, 4> Card::suits{ 'D','H','S','C' };
Card Card::currentCard;

Card::Card() {
	int n = rand() % 13, s = rand() % 4;
	num = Card::numbers.at(n);
	suit = Card::suits.at(s);
}

bool Card::compare(Card* card) {
	if ((this->getNum() == card->getNum()) || this->getSuit() == card->getSuit()) {
		return true;
	}

	else {
		return false;
	}
}

void Card::displayCardInField(Card* card) {
	Card::currentCard = *card;
	cout << "Card: " << card->getNum() << card->getSuit() << "\n\n";
}

char Card::getNum() {
	return num;
}

char Card::getSuit() {
	return suit;
}

Player::Player() {
	isTurn = false;
	suitCall = '\0';
	for (int i = 0; i < hand.size(); ++i) {
		hand[i] = new Card();
	}
}

void Player::drawCard() {
	for (int i = 0; i < hand.size(); ++i) {
		if (hand[i] == nullptr) {
			hand[i] = new Card();
			break;
		}
	}
}

Card* Player::getCard(int index) {
	while (index < 1 || index > 8) {
		cout << "Invalid entry, try again: ";
		cin >> index;
	}
	return hand[index-1];
}

void Player::setIsTurn(bool isTurn) {
	this->isTurn = isTurn;
}

bool Player::getIsTurn() {
	return isTurn;
}

void Player::setSuitCall(char suitCall) {
	while (suitCall != 'H' && suitCall != 'D' && suitCall != 'C' && suitCall != 'S') {
		cout << "Invalid entry, try again: ";
		cin >> suitCall;
	}
	this->suitCall = suitCall;
}

char Player::getSuitCall() {
	return suitCall;
}

void Player::clearSuitCall() {
	this->suitCall = '\0';
}

int Player::cardCount() {
	int count = 0;

	for (Card* card : hand) {
		if (card != nullptr) {
			++count;
		}
	}
	return count;
}

void Player::showHand() {
	int count = 0;

	for (Card* card : hand) {
		++count;
		cout << count << ": ";

		if (card != nullptr) {
			cout << card->getNum() << "" << card->getSuit() << endl;
		}

		else {
			cout << endl;
		}
	}
}

void Player::removeCard(int index) {
	hand[index-1] = nullptr;
}

void Player::crazy8() {
	char suitCall;
	cout << "Enter suit of choice (D, H, S, C): ";
	cin >> suitCall;
	setSuitCall(suitCall);
}

void Player::drawTwo() {
	drawCard();
	drawCard();
}

void Player::dropPairs(Card** cards, array<int, 8> indexes, int count, int index) {

	for (int i = 0; i < count; ++i) {
		cards[i] = getCard(indexes[i]);

		while (cards[i] == nullptr) {
			cout << "Invalid entry, pick another card: ";
			cin >> index;
			cards[i] = getCard(index);
			indexes[i] = index;
		}
	}
}

void Game::WinLose(Player &player) {
	player.cardCount() == 0 ? cout << "Player 1 wins" << endl : cout << "Player 2 wins" << endl;
}